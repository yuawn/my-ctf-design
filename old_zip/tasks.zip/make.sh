#!/bin/bash

cd final_countdown && make
cd ../shellcode_revenge++ && make
cd ../memo_manager && make
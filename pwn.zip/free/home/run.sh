#!/bin/bash
#
exec 2>/dev/null
timeout 90 /home/free/free
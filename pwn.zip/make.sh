#!/bin/bash

cd final_countdown && make
cd ../name && make
cd ../memo_manager && make
cd ../joke && make
cd ../three_page && make